package Wpro1;

public class DBProperties {

	public static final String URL = "jdbc:oracle:thin:@localhost:1521:xe";//상수로 지정
	public static final String UID = "HR";
	public static final String UPW = "hr";
}
